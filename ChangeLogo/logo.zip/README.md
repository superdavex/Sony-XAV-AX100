# Change Startup Logo

Logo requires a 800x480 image.  Any format should work.  If the image is not 800x480 it will resized.

# Added windows batch file version.  
1. Extract all the files in logo.zip to your pc.
2. Run createXAVlogo.bat and follow the prompts.



#SD
